#
# xSqlCreateVirtualDataDisk: DSC resource to create a virtual data disk 
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfLogDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfLogColumns = 0,

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfDataDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfDataColumns = 0,

        [parameter(Mandatory = $true)]
        [System.String]$LogDiskLetter,
        
        [parameter(Mandatory = $true)]
        [System.String]$DataDiskLetter,

        [parameter(Mandatory = $true)]
        [System.String]$OptimizationType,

        [parameter(Mandatory = $true)]
        [System.Uint32]$StartingDeviceID,

        [ValidateNotNullOrEmpty()]
        [Bool]$RebootVirtualMachine = $false 
    )
    
    $bConfigured = Test-TargetResource -NumberOfLogDisks $NumberOfLogDisks -NumberOfLogColumns $NumberOfLogColumns -NumberOfDataDisks $NumberOfDataDisks -NumberOfDataColumns $NumberOfDataColumns -LogDiskLetter $LogDiskLetter -DataDiskLetter $DataDiskLetter -OptimizationType $OptimizationType -RebootVirtualMachine $RebootVirtualMachine

    $retVal = @{
        NumberOfLogDisks = $NumberOfLogDisks
        NumberOfLogColumns = $NumberOfLogColumns
        NumberOfDataDisks = $NumberOfDataDisks
        NumberOfDataColumns = $NumberOfDataColumns
        LogDiskLetter = $LogDiskLetter
        DataDiskLetter = $DataDiskLetter
        OptimizationType = $OptimizationType
        StartingDeviceID = $StartingDeviceID
        RebootVirtualMachine = $RebootVirtualMachine
    }

    $retVal
}


function Test-TargetResource
{
    [OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfLogDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfLogColumns = 0,

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfDataDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfDataColumns = 0,
        
        [parameter(Mandatory = $true)]
        [System.String]$LogDiskLetter,

        [parameter(Mandatory = $true)]
        [System.String]$DataDiskLetter,

        [parameter(Mandatory = $true)]
        [System.String]$OptimizationType,

        [parameter(Mandatory = $true)]
        [System.Uint32]$StartingDeviceID,

        [ValidateNotNullOrEmpty()]
        [Bool]$RebootVirtualMachine = $false 
    )
    
    $dataResult = [System.Boolean]
    $logResult = [System.Boolean]

    Try 
    {
        if (Get-volume -DriveLetter $DataDiskLetter -ErrorAction SilentlyContinue) 
        {
            Write-Verbose "'$($DataDiskLetter)' exists on target."

            $dataResult = $true
        }
        else
        {
            Write-Verbose "'$($DataDiskLetter)' not Found."

            $dataResult = $false
        }
    }
    Catch 
    {
        throw "An error occured getting the '$($DataDiskLetter)' drive informations. Error: $($_.Exception.Message)"
    }

    Try 
    {
        if (Get-volume -DriveLetter $LogDiskLetter -ErrorAction SilentlyContinue) 
        {
            Write-Verbose "'$($LogDiskLetter)' exists on target."

            $logResult = $true
        }
        else
        {
            Write-Verbose "'$($LogDiskLetter)' not Found."

            $logResult = $false
        }
    }
    Catch 
    {
        throw "An error occured getting the '$($LogDiskLetter)' drive informations. Error: $($_.Exception.Message)"
    }

    $dataResult -and $logResult    
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfLogDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfLogColumns = 0,

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfDataDisks,

        [ValidateNotNullOrEmpty()]
        [System.Uint32]
        $NumberOfDataColumns = 0,
        
        [parameter(Mandatory = $true)]
        [System.String]$LogDiskLetter,

        [parameter(Mandatory = $true)]
        [System.String]$DataDiskLetter,

        [parameter(Mandatory = $true)]
        [System.String]$OptimizationType,

        [parameter(Mandatory = $true)]
        [System.Uint32]$StartingDeviceID,

        [ValidateNotNullOrEmpty()]
        [Bool]$RebootVirtualMachine = $false 
    )

    #Validating Paramters
    if ($NumberOfDataColumns -gt $NumberOfDataDisks)
    {
        Write-Verbose "NumberOfDataColumns ( $($NumberOfDataColumns) ) if greater than NumberOfDataDisks ( $($NumberOfDataDisks) ). exiting"
        return $false
    }

    if ($NumberOfLogColumns -gt $NumberOfLogDisks)
    {
        Write-Verbose "NumberOfLogColumns ( $($NumberOfLogColumns) ) if greater than NumberOfLogDisks ( $($NumberOfLogDisks) ). exiting"
        return $false
    } 
        
    # Set the reboot flag if necessary
    if ($RebootVirtualMachine -eq $true)
    {
        $global:DSCMachineStatus = 1
    }
    
    #Validtion OptimizationType
    if(($OptimizationType.ToUpper().CompareTo("OLTP") -eq 1) -and ($OptimizationType.ToUpper().CompareTo("GENERAL") -eq 1) -and ($OptimizationType.ToUpper().CompareTo("DW") -eq 1))
    {
        Write-Error "OptimizationType $($OptimizationType) is not recognized, exiting..."
        return $false
    }
    
    # Setting up the Interleave size based on OptimizationType
    $InterleaveSizeInByte = 262144
    
    if($OptimizationType.ToUpper().CompareTo("OLTP") -eq 0)
    {
       $InterleaveSizeInByte = 65536
    }

    #Generating VirtualDiskName/StoragePoolName/VoulumeLabelName
    $NewDataVirtualDiskName = 'SQLVMDataVirtualDisk'
    $NewDataStoragePoolName = 'SQLVMDataStoragePool'
    $NewDataVolumeLabelName = 'Data'
    # $NewDataVolumeLabelName = 'SQLVMDATA'

    $NewLogVirtualDiskName = 'SQLVMLogVirtualDisk'
    $NewLogStoragePoolName = 'SQLVMLogStoragePool'
    $NewLogVolumeLabelName = 'Log'

    #Get Disks for storage pool
    $logStartingDeviceId = $DeviceID + $NumberOfDataDisks
    $DisksForDataStoragePool = GetPhysicalDisks -DeviceID $StartingDeviceID -NumberOfDisks $NumberOfDataDisks
    $DisksForLogStoragePool = GetPhysicalDisks -DeviceID $logStartingDeviceId -NumberOfDisks $NumberOfLogDisks

    if (!$DisksForDataStoragePool)
    {
        Write-Error "Unable to get any disks for creating Data Storage Pool. exiting"
        return $false
    }

    if (!$DisksForLogStoragePool)
    {
        Write-Error "Unable to get any disks for creating Log Storage Pool. exiting"
        return $false
    }


    if ($DisksForDataStoragePool -and (1 -eq $NumberOfDataDisks))
    {
        Write-Verbose "Got $($NumberOfDataDisks) disks for creating Data Storage Pool. "
    }
    elseif ($DisksForDataStoragePool -and ($DisksForDataStoragePool.Count -eq $NumberOfDataDisks))
    {
        Write-Verbose "Got $($NumberOfDataDisks) disks for creating Data Storage Pool. "
    }
    else 
    {
        Write-Error "Unable to get $($NumberOfDataDisks) disks for creating Data Storage Pool. exiting"
        return $false
    }

    if ($DisksForLogStoragePool -and (1 -eq $NumberOfLogDisks))
    {
        Write-Verbose "Got $($NumberOfLogDisks) disks for creating Log Storage Pool. "
    }
    elseif ($DisksForLogStoragePool -and ($DisksForLogStoragePool.Count -eq $NumberOfLogDisks))
    {
        Write-Verbose "Got $($NumberOfLogDisks) disks for creating Log Storage Pool. "
    }
    else 
    {
        Write-Error "Unable to get $($NumberOfLogDisks) disks for creating Log Storage Pool. exiting"
        return $false
    }

    #Creating Storage Pool
    Write-Verbose "Creating Storage Pool $($NewDataStoragePoolName)"
    New-StoragePool -FriendlyName $NewDataStoragePoolName -StorageSubSystemUniqueId (Get-StorageSubSystem)[0].uniqueID -PhysicalDisks $DisksForDataStoragePool
    Verify-NewStoragePool -StoragePoolName $NewDataStoragePoolName -TimeOut 20
    Write-Verbose "Storage Pool $($NewDataStoragePoolName) created successfully."        
    #Creating Virtual Disk
    Write-Verbose "Creating Virtual Disk $($NewDataVirtualDiskName)"
    if ($NumberOfDataColumns -eq 0)
    {   
        Write-Verbose "Creating Virtual Disk $($NewDataVirtualDiskName) with AutoNumberOfColumns"
        New-VirtualDisk -FriendlyName $NewDataVirtualDiskName -StoragePoolFriendlyName $NewDataStoragePoolName -UseMaximumSize -Interleave $InterleaveSizeInByte -AutoNumberOfColumns  -ResiliencySettingName Simple -ProvisioningType Fixed
    }
    else 
    {
        Write-Verbose "Creating Virtual Disk $($NewDataVirtualDiskName) with $($NumberOfDataColumns) number of columns"
        New-VirtualDisk -FriendlyName $NewDataVirtualDiskName -StoragePoolFriendlyName $NewDataStoragePoolName -UseMaximumSize -Interleave $InterleaveSizeInByte -NumberOfColumns $NumberOfDataColumns -ResiliencySettingName Simple -ProvisioningType Fixed
    }
    #Validating Virtual Disk
    Verify-VirtualDisk -VirtualDiskName $NewDataVirtualDiskName -TimeOut 20
    #Initializing Disk
    Write-Verbose "Initializing Virtual Disk $($NewDataVirtualDiskName)"
    Initialize-Disk -VirtualDisk (Get-VirtualDisk -FriendlyName $NewDataVirtualDiskName)
    #Creating Partition
    $dataDiskNumber = ((Get-VirtualDisk -FriendlyName $NewDataVirtualDiskName | Get-Disk).Number)
    Write-Verbose 'Creating Data Partition'
    New-Partition -DiskNumber $dataDiskNumber -UseMaximumSize -DriveLetter $DataDiskLetter
    Verify-Partition -DiskLetter $DataDiskLetter -TimeOut 20
    #Formatting Volume
    #All file systems that are used by Windows organize your hard disk based on cluster size (also known as allocation unit size). 
    #Cluster size represents the smallest amount of disk space that can be used to hold a file. 
    #When file sizes do not come out to an even multiple of the cluster size, additional space must be used to hold the file (up to the next multiple of the cluster size). On the typical hard disk partition, the average amount of space that is lost in this manner can be calculated by using the equation (cluster size)/2 * (number of files).  
    #In our case, the largest possible size is 64TB so we make 16KB as the default size and based on calculation even there is 1 million files on this disk, the extra wasted size is about 4GB
    Write-Verbose 'Formatting Data Volume and Assigning Drive Letter'
    Format-Volume -DriveLetter $DataDiskLetter -FileSystem NTFS -AllocationUnitSize 16384 -NewFileSystemLabel $NewDataVolumeLabelName -Confirm:$false -Force
    Verify-Volume -DiskLetter $DataDiskLetter -TimeOut 20

    #Creating Storage Pool
    Write-Verbose "Creating Storage Pool $($NewLogStoragePoolName)"
    New-StoragePool -FriendlyName $NewLogStoragePoolName -StorageSubSystemUniqueId (Get-StorageSubSystem)[0].uniqueID -PhysicalDisks $DisksForLogStoragePool
    Verify-NewStoragePool -StoragePoolName $NewLogStoragePoolName -TimeOut 20
    Write-Verbose "Storage Pool $($NewLogStoragePoolName) created successfully." 
    #Creating Virtual Disk
    Write-Verbose "Creating Virtual Disk $($NewLogVirtualDiskName)"
    if ($NumberOfLogColumns -eq 0)
    {   
        Write-Verbose "Creating Virtual Disk $($NewLogVirtualDiskName) with AutoNumberOfColumns"
        New-VirtualDisk -FriendlyName $NewLogVirtualDiskName -StoragePoolFriendlyName $NewLogStoragePoolName -UseMaximumSize -Interleave $InterleaveSizeInByte -AutoNumberOfColumns  -ResiliencySettingName Simple -ProvisioningType Fixed
    }
    else 
    {
        Write-Verbose "Creating Virtual Disk $($NewLogVirtualDiskName) with $($NumberOfLogColumns) number of columns"
        New-VirtualDisk -FriendlyName $NewLogVirtualDiskName -StoragePoolFriendlyName $NewLogStoragePoolName -UseMaximumSize -Interleave $InterleaveSizeInByte -NumberOfColumns $NumberOfLogColumns -ResiliencySettingName Simple -ProvisioningType Fixed
    }
    #Validating Virtual Disk
    Verify-VirtualDisk -VirtualDiskName $NewLogVirtualDiskName -TimeOut 20
    #Initializing Disk
    Write-Verbose "Initializing Virtual Disk $($NewLogVirtualDiskName)"
    Initialize-Disk -VirtualDisk (Get-VirtualDisk -FriendlyName $NewLogVirtualDiskName)
    #Creating Partition
    $logDiskNumber = ((Get-VirtualDisk -FriendlyName $NewLogVirtualDiskName | Get-Disk).Number)
    Write-Verbose 'Creating Data Partition'
    New-Partition -DiskNumber $logDiskNumber -UseMaximumSize -DriveLetter $LogDiskLetter
    Verify-Partition -DiskLetter $LogDiskLetter -TimeOut 20 
    #Formatting Volume
    Write-Verbose 'Formatting Log Volume and Assigning Drive Letter'
    Format-Volume -DriveLetter $LogDiskLetter -FileSystem NTFS -AllocationUnitSize 16384 -NewFileSystemLabel $NewLogVolumeLabelName -Confirm:$false -Force
    Verify-Volume -DiskLetter $LogDiskLetter -TimeOut 20


    return $true
}

function GetPhysicalDisks
{
    param
    (
        [parameter(Mandatory = $true)]
        [System.Uint32]
        $DeviceID,

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $NumberOfDisks
    )

    $upperDeviceID = $DeviceID + $NumberOfDisks - 1

    $Disks= Get-PhysicalDisk | Where-Object { ([int]$_.DeviceId -ge $DeviceID) -and ([int]$_.DeviceId -le $upperDeviceID) -and ($_.CanPool -eq $true)}

    return $Disks
}


function Verify-NewStoragePool{
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $StoragePoolName

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $TimeOut
    )

   $timespan = new-timespan -Seconds $TimeOut

   $sw = [diagnostics.stopwatch]::StartNew()

    while ($sw.elapsed -lt $timespan){
        
    $StoragePool = Get-StoragePool -FriendlyName $StoragePoolName -ErrorAction SilentlyContinue

        if ($StoragePool){
            return $true
        }
 
        start-sleep -seconds 1
    }
 
    Write-Error "Unable to find Storage Pool $($StoragePoolName) after $($TimeOut)"
}


function Verify-VirtualDisk{
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $VirtualDiskName

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $TimeOut
    )

   $timespan = new-timespan -Seconds $TimeOut

   $sw = [diagnostics.stopwatch]::StartNew()

    while ($sw.elapsed -lt $timespan){
        
    $VirtualDisk = Get-VirtualDisk -FriendlyName $VirtualDiskName -ErrorAction SilentlyContinue

        if ($VirtualDisk){
            return $true
        }
 
        start-sleep -seconds 1
    }
 
    Write-Error "Unable to find Vitrual Disk $($VirtualDiskName) after $($TimeOut)"
}

function Verify-Partition{
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $DiskLetter

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $TimeOut
    )

   $timespan = new-timespan -Seconds $TimeOut

   $sw = [diagnostics.stopwatch]::StartNew()

   while ($sw.elapsed -lt $timespan){
        
   $Partition = Get-partition -DriveLetter $DiskLetter -ErrorAction SilentlyContinue

       if ($Partition){
            return $true
       }
 
       start-sleep -seconds 1
    }
 
   Write-Error "Unable to find Partition $($DiskLetter) after $($TimeOut)"
}

function Verify-Volume{
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $DiskLetter

        [parameter(Mandatory = $true)]
        [System.Uint32]
        $TimeOut
    )

   $timespan = new-timespan -Seconds $TimeOut

   $sw = [diagnostics.stopwatch]::StartNew()

   while ($sw.elapsed -lt $timespan){
        
   $Volume = Get-Volume -DriveLetter $DiskLetter -ErrorAction SilentlyContinue

       if ($Volume){
            return $true
       }
 
       start-sleep -seconds 1
    }
 
   Write-Error "Unable to find Volume $($DiskLetter) after $($TimeOut)"
}

Export-ModuleMember -Function *-TargetResource
