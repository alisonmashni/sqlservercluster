Configuration Foobar
{
    param (
        [Parameter(Mandatory)]
        [String]$DomainName
    )

    Import-DscResource -ModuleName 'PSDscResources'

    Node localhost
    {
        Environment CreatePathEnvironmentVariable
        {
            Name = 'TestPathEnvironmentVariable2'
            Value = (Get-NetBIOSName -DomainName $DomainName)
            Ensure = 'Present'
            Path = $true
            Target = @('Process', 'Machine')
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

# Foobar -OutputPath:"./Foobar"